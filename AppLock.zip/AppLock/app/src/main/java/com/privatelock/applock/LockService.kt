package com.privatelock.applock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.view.ContextThemeWrapper
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Runs in the background while protection is on. Several times a second it checks which app
 * is on screen (using Usage access). If that app is locked, it covers it with the lock screen.
 */
class LockService : Service() {

    private lateinit var prefs: Prefs
    private lateinit var usage: UsageStatsManager
    private lateinit var windows: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var overlay: LockView? = null
    private var overlayPackage: String? = null
    private var foreground: String? = null
    private var lastQuery = 0L
    private var lastEventTime = 0L
    private var polling = false

    private val poll = object : Runnable {
        override fun run() {
            tick()
            if (polling) handler.postDelayed(this, POLL_MS)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // Everything locks again when the screen turns off.
                    Session.lockAll()
                    stopPolling()
                    hideOverlay()
                }
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> startPolling()
            }
        }
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!prefs.autoLockNew || intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
            val pkg = intent.data?.schemeSpecificPart ?: return
            if (pkg == packageName) return
            if (packageManager.getLaunchIntentForPackage(pkg) != null) {
                prefs.setLocked(pkg, true)
                updateNotification()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        usage = getSystemService(UsageStatsManager::class.java)
        windows = getSystemService(WindowManager::class.java)
        createChannel()

        val screenFilter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        ContextCompat.registerReceiver(this, screenReceiver, screenFilter, ContextCompat.RECEIVER_NOT_EXPORTED)
        val packageFilter = IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") }
        ContextCompat.registerReceiver(this, packageReceiver, packageFilter, ContextCompat.RECEIVER_NOT_EXPORTED)

        val power = getSystemService(PowerManager::class.java)
        if (power == null || power.isInteractive) startPolling()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), type)
        } catch (e: Exception) {
            stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopPolling()
        hideOverlay()
        try {
            unregisterReceiver(screenReceiver)
            unregisterReceiver(packageReceiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startPolling() {
        if (polling) return
        polling = true
        lastQuery = 0L
        handler.post(poll)
    }

    private fun stopPolling() {
        polling = false
        handler.removeCallbacks(poll)
    }

    @Suppress("DEPRECATION")
    private fun tick() {
        val now = System.currentTimeMillis()
        val from = if (lastQuery == 0L) now - 60_000 else lastQuery - 2_000
        lastQuery = now
        var newest: String? = null
        try {
            val events = usage.queryEvents(from, now)
            val event = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && event.timeStamp >= lastEventTime) {
                    lastEventTime = event.timeStamp
                    newest = event.packageName
                }
            }
        } catch (_: Exception) {
        }

        val pkg = newest
        if (pkg != null && pkg != foreground && pkg !in IGNORED_PACKAGES) {
            foreground?.let { Session.onLeft(it, now) }
            Session.onReturn(pkg, now, prefs.relockSeconds * 1000L)
            foreground = pkg
        }
        evaluate()
    }

    private fun evaluate() {
        val pkg = foreground
        if (pkg == null || pkg == packageName || !prefs.protectionOn || !Perms.overlay(this)) {
            hideOverlay()
            return
        }
        if (pkg in prefs.effectiveLocked() && !Session.isUnlocked(pkg)) showOverlay(pkg) else hideOverlay()
    }

    private fun showOverlay(pkg: String) {
        if (overlay != null && overlayPackage == pkg) return
        hideOverlay()

        val (label, icon) = describe(pkg)
        val fingerprint = prefs.fingerprint && Bio.available(this)
        val themed = ContextThemeWrapper(this, R.style.Theme_AppLock)
        val view = LockView(
            themed, prefs, label, icon, fingerprint,
            topInset = dp(36), bottomInset = dp(24),
            onUnlock = {
                Session.unlock(pkg)
                hideOverlay()
            },
            onFingerprint = {
                val intent = Intent(this, BiometricActivity::class.java)
                    .putExtra(BiometricActivity.EXTRA_PACKAGE, pkg)
                    .putExtra(BiometricActivity.EXTRA_LABEL, label)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            },
            onBack = { goHome() },
        )
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        ).apply {
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            windows.addView(view, params)
            overlay = view
            overlayPackage = pkg
        } catch (_: Exception) {
        }
    }

    private fun hideOverlay() {
        val view = overlay ?: return
        try {
            windows.removeView(view)
        } catch (_: Exception) {
        }
        overlay = null
        overlayPackage = null
    }

    private fun goHome() {
        val home = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(home)
        } catch (_: Exception) {
        }
    }

    private fun describe(pkg: String): Pair<String, Drawable> {
        val fallbackIcon = ContextCompat.getDrawable(this, R.mipmap.ic_launcher)!!
        return try {
            val info = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(info).toString() to packageManager.getApplicationIcon(info)
        } catch (_: Exception) {
            val name = if (pkg in Prefs.PROTECTED_PACKAGES && pkg != Prefs.SETTINGS_PACKAGE) getString(R.string.app_installer) else pkg
            name to fallbackIcon
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW).apply {
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val count = prefs.lockedApps().size
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(resources.getQuantityString(R.plurals.apps_protected, count, count))
            .setColor(Palette.VIOLET)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification() {
        try {
            getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, buildNotification())
        } catch (_: Exception) {
        }
    }

    companion object {
        private const val CHANNEL_ID = "protection"
        private const val NOTIFICATION_ID = 1
        private const val POLL_MS = 200L

        /** System screens that briefly appear over apps; they don't count as leaving an app. */
        private val IGNORED_PACKAGES = setOf("android", "com.android.systemui")

        /** Starts or stops the service to match the current settings. */
        fun sync(context: Context) {
            val prefs = Prefs(context)
            val intent = Intent(context, LockService::class.java)
            if (prefs.protectionOn && prefs.hasCredential && Perms.all(context)) {
                try {
                    ContextCompat.startForegroundService(context, intent)
                } catch (_: Exception) {
                }
            } else {
                context.stopService(intent)
            }
        }
    }
}
