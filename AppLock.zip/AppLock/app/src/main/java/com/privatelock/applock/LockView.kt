package com.privatelock.applock

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher

/**
 * The purple lock screen. Used both as the overlay over locked apps and inside App Lock itself.
 * Shows a keypad for a PIN or a text box for a password.
 */
@SuppressLint("ViewConstructor")
class LockView(
    context: Context,
    private val prefs: Prefs,
    appLabel: String,
    appIcon: Drawable,
    private val showFingerprint: Boolean,
    topInset: Int,
    bottomInset: Int,
    private val onUnlock: () -> Unit,
    private val onFingerprint: () -> Unit,
    private val onBack: () -> Unit,
) : FrameLayout(context) {

    private val isPassword = prefs.isPassword
    private val pinLength = prefs.pinLength
    private val entered = StringBuilder()
    private val dots = ArrayList<View>()
    private var dotsRow: LinearLayout? = null
    private var passwordField: EditText? = null
    private val message: TextView = context.label("", 14f, 0xFFFFE3F4.toInt(), 700).apply {
        gravity = Gravity.CENTER
        visibility = View.GONE
    }
    private var showingLockout = false
    private val ticker = Handler(Looper.getMainLooper())
    private var backCallback: Any? = null
    private val lockoutTick = Runnable { checkLockout() }

    init {
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Palette.LOCK1, Palette.LOCK2, Palette.LOCK3),
        )
        isFocusable = true
        isFocusableInTouchMode = true

        // Soft decorative circles.
        addView(View(context).apply { background = oval(0x14FFFFFF) },
            LayoutParams(dp(260), dp(260)).apply {
                leftMargin = -dp(90)
                topMargin = -dp(60)
            })
        addView(View(context).apply { background = oval(0x24FFA0C8) },
            LayoutParams(dp(280), dp(280), Gravity.END or Gravity.CENTER_VERTICAL).apply {
                rightMargin = -dp(110)
            })

        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), topInset + dp(40), dp(28), bottomInset + dp(16))
        }
        val scroll = ScrollView(context).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            addView(column, LayoutParams(MATCH, WRAP))
        }
        addView(scroll, LayoutParams(MATCH, MATCH))

        // The locked app's real icon, with a small lock badge.
        val iconFrame = FrameLayout(context)
        iconFrame.addView(ImageView(context).apply {
            setImageDrawable(appIcon)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LayoutParams(dp(82), dp(82)))
        iconFrame.addView(FrameLayout(context).apply {
            background = oval(Palette.WHITE)
            elevation = context.dpf(4)
            addView(context.iconView(R.drawable.ic_lock, Palette.VIOLET), LayoutParams(dp(17), dp(17), Gravity.CENTER))
        }, LayoutParams(dp(34), dp(34), Gravity.BOTTOM or Gravity.END))
        column.addView(iconFrame, lin(dp(94), dp(94)))

        // "Password, please." (or "PIN, please.") with the locked app's name underneath.
        column.addView(context.label(
            context.getString(if (isPassword) R.string.password_please else R.string.pin_please),
            26f, Palette.WHITE, 800,
        ).apply {
            gravity = Gravity.CENTER
            letterSpacing = -0.01f
        }, lin(MATCH, WRAP, top = dp(18)))
        column.addView(context.label(
            context.getString(R.string.app_locked, appLabel),
            15f, 0xDBFFFFFF.toInt(), 500,
        ).apply { gravity = Gravity.CENTER }, lin(MATCH, WRAP, top = dp(6)))

        if (isPassword) {
            column.addView(buildPasswordBox(), lin(MATCH, WRAP, top = dp(30)))
            column.addView(message, lin(MATCH, WRAP, top = dp(14)))
            if (showFingerprint) {
                column.addView(orDivider(), lin(MATCH, WRAP, top = dp(18)))
                column.addView(fingerprintButton(), lin(MATCH, dp(54), top = dp(18)))
            }
            column.addView(View(context), lin(MATCH, 0, weight = 1f))
        } else {
            val row = LinearLayout(context).apply { gravity = Gravity.CENTER }
            repeat(pinLength) { i ->
                val dot = View(context)
                dots.add(dot)
                row.addView(dot, lin(dp(15), dp(15), start = if (i > 0) dp(18) else 0))
            }
            dotsRow = row
            column.addView(row, lin(WRAP, WRAP, top = dp(28)))
            column.addView(message, lin(MATCH, WRAP, top = dp(14)))
            column.addView(View(context), lin(MATCH, 0, weight = 1f, top = dp(16)))
            column.addView(buildKeypad(), lin(MATCH, WRAP))
            updateDots()
        }

        val forgot = context.label(
            context.getString(if (isPassword) R.string.forgot_password else R.string.forgot_pin),
            15f, Palette.WHITE, 700,
        ).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = pressable(context.dpf(12), 0x33FFFFFF)
            setOnClickListener { showMessage(context.getString(R.string.forgot_help)) }
        }
        column.addView(forgot, lin(WRAP, WRAP, top = dp(8)))

        checkLockout()
    }

    private fun dp(value: Int): Int = context.dp(value)

    // ---------- PIN keypad ----------

    private fun buildKeypad(): LinearLayout {
        val grid = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val letters = arrayOf("", "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ")
        for (r in 0 until 3) {
            val row = LinearLayout(context)
            for (c in 0 until 3) {
                val n = r * 3 + c + 1
                row.addView(digitKey(n.toString(), letters[n - 1]), keyParams(c))
            }
            grid.addView(row, lin(MATCH, WRAP, top = if (r > 0) dp(14) else 0))
        }
        val last = LinearLayout(context)
        last.addView(
            if (showFingerprint) iconKey(R.drawable.ic_fingerprint, R.string.use_fingerprint) { onFingerprint() }
            else View(context),
            keyParams(0),
        )
        last.addView(digitKey("0", ""), keyParams(1))
        last.addView(iconKey(R.drawable.ic_backspace, R.string.delete_digit) {
            if (entered.isNotEmpty()) {
                entered.deleteCharAt(entered.length - 1)
                updateDots()
            }
        }, keyParams(2))
        grid.addView(last, lin(MATCH, WRAP, top = dp(14)))
        return grid
    }

    private fun keyParams(column: Int) = lin(0, dp(72), weight = 1f, start = if (column > 0) dp(22) else 0)

    private fun digitKey(digit: String, letters: String): View = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = ripple(roundRect(0x24FFFFFF, context.dpf(36), dp(1), 0x42FFFFFF), 0x40FFFFFF)
        contentDescription = digit
        addView(context.label(digit, 28f, Palette.WHITE, 600).apply { gravity = Gravity.CENTER }, lin(WRAP, WRAP))
        if (letters.isNotEmpty()) {
            addView(context.label(letters, 10f, Palette.WHITE, 700).apply {
                letterSpacing = 0.15f
                gravity = Gravity.CENTER
            }, lin(WRAP, WRAP, top = dp(2)))
        }
        setOnClickListener { onDigit(digit) }
    }

    private fun iconKey(icon: Int, description: Int, onClick: () -> Unit): View = FrameLayout(context).apply {
        background = pressable(context.dpf(36), 0x33FFFFFF)
        contentDescription = context.getString(description)
        addView(context.iconView(icon, Palette.WHITE), LayoutParams(dp(30), dp(30), Gravity.CENTER))
        setOnClickListener { onClick() }
    }

    private fun onDigit(digit: String) {
        if (lockedOut() || entered.length >= pinLength) return
        entered.append(digit)
        updateDots()
        if (!showingLockout) hideMessage()
        if (entered.length == pinLength) {
            if (prefs.verify(entered.toString())) {
                succeed()
            } else {
                fail(R.string.wrong_pin)
                entered.setLength(0)
                postDelayed({ updateDots() }, 250)
            }
        }
    }

    private fun updateDots() {
        dots.forEachIndexed { i, dot ->
            dot.background = if (i < entered.length) oval(Palette.WHITE)
            else GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), 0x99FFFFFF.toInt())
            }
        }
    }

    // ---------- Password ----------

    private fun buildPasswordBox(): View {
        val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val frame = FrameLayout(context)
        val field = EditText(context).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            typeface = font(600)
            textSize = 20f
            setTextColor(Palette.WHITE)
            setHintTextColor(0xBFFFFFFF.toInt())
            hint = context.getString(R.string.password_hint)
            maxLines = 1
            imeOptions = EditorInfo.IME_ACTION_DONE
            background = roundRect(0x29FFFFFF, context.dpf(18), dp(1), 0x59FFFFFF)
            setPadding(dp(20), 0, dp(58), 0)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_DONE) {
                    submitPassword()
                    true
                } else false
            }
        }
        passwordField = field
        frame.addView(field, LayoutParams(MATCH, dp(58)))
        val eye = context.iconView(R.drawable.ic_eye, Palette.WHITE).apply {
            contentDescription = context.getString(R.string.show_password)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = pressable(context.dpf(13), 0x33FFFFFF)
            setOnClickListener {
                field.transformationMethod =
                    if (field.transformationMethod is PasswordTransformationMethod) null
                    else PasswordTransformationMethod.getInstance()
                field.setSelection(field.text.length)
            }
        }
        frame.addView(eye, LayoutParams(dp(44), dp(44), Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = dp(7)
        })
        box.addView(frame, lin(MATCH, WRAP))

        val unlock = context.label(context.getString(R.string.unlock), 16f, 0xFF4B2BC9.toInt(), 800).apply {
            gravity = Gravity.CENTER
            background = ripple(roundRect(Palette.WHITE, context.dpf(18)), 0x225B3BE8)
            elevation = context.dpf(6)
            setOnClickListener { submitPassword() }
        }
        box.addView(unlock, lin(MATCH, dp(56), top = dp(14)))
        return box
    }

    private fun orDivider(): View = LinearLayout(context).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(View(context).apply { setBackgroundColor(0x4DFFFFFF) }, lin(0, dp(1), weight = 1f))
        addView(context.label(context.getString(R.string.or), 13f, 0xDBFFFFFF.toInt(), 600), lin(WRAP, WRAP, start = dp(12), end = dp(12)))
        addView(View(context).apply { setBackgroundColor(0x4DFFFFFF) }, lin(0, dp(1), weight = 1f))
    }

    private fun fingerprintButton(): View = LinearLayout(context).apply {
        gravity = Gravity.CENTER
        background = ripple(roundRect(0x1AFFFFFF, context.dpf(18), dp(1), 0x59FFFFFF), 0x33FFFFFF)
        addView(context.iconView(R.drawable.ic_fingerprint, Palette.WHITE), lin(dp(22), dp(22), end = dp(10)))
        addView(context.label(context.getString(R.string.use_fingerprint), 15f, Palette.WHITE, 700), lin(WRAP, WRAP))
        setOnClickListener { onFingerprint() }
    }

    private fun submitPassword() {
        val field = passwordField ?: return
        if (lockedOut()) return
        val text = field.text.toString()
        if (text.isEmpty()) return
        if (prefs.verify(text)) {
            hideKeyboard()
            succeed()
        } else {
            field.text.clear()
            fail(R.string.wrong_password)
        }
    }

    // ---------- Shared ----------

    private fun succeed() {
        Session.registerSuccess()
        onUnlock()
    }

    private fun fail(messageRes: Int) {
        val target: View = dotsRow ?: passwordField ?: this
        ObjectAnimator.ofFloat(target, "translationX", 0f, 18f, -18f, 12f, -12f, 6f, 0f)
            .setDuration(380)
            .start()
        if (Session.registerFailure(System.currentTimeMillis())) {
            checkLockout()
        } else {
            showMessage(context.getString(messageRes))
        }
    }

    private fun lockedOut(): Boolean = System.currentTimeMillis() < Session.lockoutUntil

    private fun checkLockout() {
        ticker.removeCallbacks(lockoutTick)
        val remaining = Session.lockoutUntil - System.currentTimeMillis()
        if (remaining > 0) {
            showingLockout = true
            val seconds = ((remaining + 999) / 1000).toInt()
            showMessage(context.getString(R.string.too_many, seconds))
            ticker.postDelayed(lockoutTick, 1000)
        } else if (showingLockout) {
            showingLockout = false
            hideMessage()
        }
    }

    private fun showMessage(text: String) {
        message.text = text
        message.visibility = View.VISIBLE
    }

    private fun hideMessage() {
        message.visibility = View.GONE
    }

    private fun hideKeyboard() {
        val imm = context.getSystemService(InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(windowToken, 0)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) onBack()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (Build.VERSION.SDK_INT >= 33) {
            val callback = OnBackInvokedCallback { onBack() }
            findOnBackInvokedDispatcher()?.registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_OVERLAY, callback,
            )
            backCallback = callback
        }
        val field = passwordField
        if (field != null) {
            post {
                field.requestFocus()
                context.getSystemService(InputMethodManager::class.java)?.showSoftInput(field, 0)
            }
        } else {
            requestFocus()
        }
    }

    override fun onDetachedFromWindow() {
        if (Build.VERSION.SDK_INT >= 33) {
            val callback = backCallback
            if (callback is OnBackInvokedCallback) {
                findOnBackInvokedDispatcher()?.unregisterOnBackInvokedCallback(callback)
            }
            backCallback = null
        }
        ticker.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }
}
