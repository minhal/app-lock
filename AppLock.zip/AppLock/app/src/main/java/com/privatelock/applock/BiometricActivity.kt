package com.privatelock.applock

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Shows the fingerprint prompt for a locked app. It has a plain purple
 * background so the locked app stays hidden while the prompt is open.
 */
class BiometricActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(EXTRA_PACKAGE)
        if (pkg == null) {
            finish()
            return
        }
        val label = intent.getStringExtra(EXTRA_LABEL) ?: getString(R.string.app_name)
        Bio.prompt(
            this,
            label,
            onSuccess = {
                Session.registerSuccess()
                Session.unlock(pkg)
                finish()
            },
            onDone = { finish() },
        )
    }

    companion object {
        const val EXTRA_PACKAGE = "package"
        const val EXTRA_LABEL = "label"
    }
}
