package com.privatelock.applock

/**
 * Which apps are unlocked right now. Kept only in memory, so everything
 * locks again when the phone restarts or the screen turns off.
 */
object Session {
    private val unlocked = HashSet<String>()
    private val leftAt = HashMap<String, Long>()

    /** Whether App Lock's own screens are unlocked. */
    @Volatile var selfUnlocked = false

    private var failedTries = 0
    @Volatile var lockoutUntil = 0L
        private set

    @Synchronized fun unlock(pkg: String) {
        unlocked.add(pkg)
        leftAt.remove(pkg)
    }

    @Synchronized fun isUnlocked(pkg: String): Boolean = pkg in unlocked

    /** The user switched away from [pkg]. */
    @Synchronized fun onLeft(pkg: String, now: Long) {
        if (pkg in unlocked) leftAt[pkg] = now
    }

    /** The user came back to [pkg]; it stays unlocked only if they return within the relock delay. */
    @Synchronized fun onReturn(pkg: String, now: Long, delayMs: Long) {
        val left = leftAt.remove(pkg) ?: return
        if (now - left > delayMs) unlocked.remove(pkg)
    }

    @Synchronized fun lockAll() {
        unlocked.clear()
        leftAt.clear()
        selfUnlocked = false
    }

    /** Returns true when this failure starts a 30-second lockout. */
    @Synchronized fun registerFailure(now: Long): Boolean {
        failedTries++
        if (failedTries >= MAX_TRIES) {
            failedTries = 0
            lockoutUntil = now + LOCKOUT_MS
            return true
        }
        return false
    }

    @Synchronized fun registerSuccess() {
        failedTries = 0
    }

    private const val MAX_TRIES = 5
    private const val LOCKOUT_MS = 30_000L
}
