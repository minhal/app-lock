package com.privatelock.applock

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Everything the app remembers, stored only on this phone.
 * The PIN or password is never stored: only a salted PBKDF2 hash of it.
 */
class Prefs(context: Context) {

    private val sp = context.applicationContext.getSharedPreferences("applock", Context.MODE_PRIVATE)

    val hasCredential: Boolean get() = sp.contains(KEY_HASH)
    val isPassword: Boolean get() = sp.getString(KEY_TYPE, TYPE_PIN) == TYPE_PASSWORD
    val pinLength: Int get() = sp.getInt(KEY_PIN_LENGTH, 4)

    fun setCredential(password: Boolean, secret: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp.edit()
            .putString(KEY_TYPE, if (password) TYPE_PASSWORD else TYPE_PIN)
            .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_HASH, Base64.encodeToString(hash(secret, salt), Base64.NO_WRAP))
            .putInt(KEY_PIN_LENGTH, secret.length)
            .apply()
    }

    fun verify(secret: String): Boolean {
        val salt = sp.getString(KEY_SALT, null) ?: return false
        val stored = sp.getString(KEY_HASH, null) ?: return false
        val computed = hash(secret, Base64.decode(salt, Base64.NO_WRAP))
        return MessageDigest.isEqual(computed, Base64.decode(stored, Base64.NO_WRAP))
    }

    private fun hash(secret: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(secret.toCharArray(), salt, ITERATIONS, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    fun lockedApps(): MutableSet<String> = HashSet(sp.getStringSet(KEY_LOCKED, null) ?: emptySet())

    fun setLocked(pkg: String, locked: Boolean) {
        val set = lockedApps()
        if (locked) set.add(pkg) else set.remove(pkg)
        sp.edit().putStringSet(KEY_LOCKED, set).apply()
    }

    /** The apps the lock screen should cover, including Settings and the installer when "Prevent uninstall" is on. */
    fun effectiveLocked(): Set<String> =
        if (preventUninstall) lockedApps() + PROTECTED_PACKAGES else lockedApps()

    var relockSeconds: Int
        get() = sp.getInt(KEY_RELOCK, 30)
        set(value) = sp.edit().putInt(KEY_RELOCK, value).apply()

    var fingerprint: Boolean
        get() = sp.getBoolean(KEY_FINGERPRINT, true)
        set(value) = sp.edit().putBoolean(KEY_FINGERPRINT, value).apply()

    var protectionOn: Boolean
        get() = sp.getBoolean(KEY_PROTECTION, true)
        set(value) = sp.edit().putBoolean(KEY_PROTECTION, value).apply()

    var preventUninstall: Boolean
        get() = sp.getBoolean(KEY_PREVENT_UNINSTALL, false)
        set(value) = sp.edit().putBoolean(KEY_PREVENT_UNINSTALL, value).apply()

    var autoLockNew: Boolean
        get() = sp.getBoolean(KEY_AUTO_LOCK, false)
        set(value) = sp.edit().putBoolean(KEY_AUTO_LOCK, value).apply()

    var askedNotifications: Boolean
        get() = sp.getBoolean(KEY_ASKED_NOTIF, false)
        set(value) = sp.edit().putBoolean(KEY_ASKED_NOTIF, value).apply()

    companion object {
        private const val ITERATIONS = 20_000
        private const val KEY_TYPE = "type"
        private const val KEY_SALT = "salt"
        private const val KEY_HASH = "hash"
        private const val KEY_PIN_LENGTH = "pin_length"
        private const val KEY_LOCKED = "locked"
        private const val KEY_RELOCK = "relock"
        private const val KEY_FINGERPRINT = "fingerprint"
        private const val KEY_PROTECTION = "protection"
        private const val KEY_PREVENT_UNINSTALL = "prevent_uninstall"
        private const val KEY_AUTO_LOCK = "auto_lock_new"
        private const val KEY_ASKED_NOTIF = "asked_notifications"
        private const val TYPE_PIN = "pin"
        private const val TYPE_PASSWORD = "password"

        const val SETTINGS_PACKAGE = "com.android.settings"
        val PROTECTED_PACKAGES = setOf(
            SETTINGS_PACKAGE,
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
        )
        val RELOCK_CHOICES = intArrayOf(0, 30, 60, 300)
    }
}
