package com.privatelock.applock

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Colors from the mockup. */
object Palette {
    val BG = 0xFFF4F2FB.toInt()
    val INK = 0xFF1C1830.toInt()
    val MUTED = 0xFF5E5874.toInt()
    val VIOLET = 0xFF5B3BE8.toInt()
    val VIOLET_LIGHT = 0xFF8C6BFF.toInt()
    val VIOLET_DARK = 0xFF3F24B8.toInt()
    val OFF = 0xFFDCD7EC.toInt()
    val LAVENDER = 0xFFECE8FF.toInt()
    val LAVENDER_INK = 0xFF3A2C7A.toInt()
    val CHEVRON = 0xFF9A93B0.toInt()
    val DIVIDER = 0xFFEEEBF6.toInt()
    val ERROR = 0xFFC62A4A.toInt()
    val LOCK1 = 0xFF3A1F9E.toInt()
    val LOCK2 = 0xFF6B3FE0.toInt()
    val LOCK3 = 0xFFC2479F.toInt()
    val PURPLE = intArrayOf(0xFF8C6BFF.toInt(), 0xFF5B3BE8.toInt())
    val CORAL = intArrayOf(0xFFFF8A65.toInt(), 0xFFFF4E7A.toInt())
    val BLUE = intArrayOf(0xFF4FA3FF.toInt(), 0xFF3B5BFF.toInt())
    val PINK = intArrayOf(0xFFF06FC4.toInt(), 0xFFB44BE0.toInt())
    val AMBER = intArrayOf(0xFFFFB547.toInt(), 0xFFFF7A3D.toInt())
    const val WHITE = Color.WHITE
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

fun Context.dpf(value: Int): Float = value * resources.displayMetrics.density

fun font(weight: Int): Typeface =
    if (Build.VERSION.SDK_INT >= 28) Typeface.create(Typeface.SANS_SERIF, weight, false)
    else if (weight >= 600) Typeface.DEFAULT_BOLD
    else Typeface.DEFAULT

fun Context.label(text: CharSequence, sizeSp: Float, color: Int, weight: Int = 400): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(color)
        typeface = font(weight)
    }

fun roundRect(color: Int, radius: Float, strokeWidth: Int = 0, strokeColor: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (strokeWidth > 0) setStroke(strokeWidth, strokeColor)
    }

fun gradientRect(
    colors: IntArray,
    radius: Float,
    orientation: GradientDrawable.Orientation = GradientDrawable.Orientation.TL_BR,
): GradientDrawable = GradientDrawable(orientation, colors).apply { cornerRadius = radius }

fun oval(color: Int): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(color)
}

fun ripple(content: Drawable, rippleColor: Int = 0x22000000): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(rippleColor), content, null)

/** A ripple with no visible background, clipped to a rounded shape. */
fun pressable(radius: Float, rippleColor: Int = 0x22000000): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(rippleColor), null, roundRect(Color.WHITE, radius))

fun Context.iconView(res: Int, color: Int): ImageView = ImageView(this).apply {
    setImageResource(res)
    imageTintList = ColorStateList.valueOf(color)
    scaleType = ImageView.ScaleType.FIT_CENTER
}

/** A rounded gradient square with a white icon in the middle. */
fun Context.iconTile(res: Int, colors: IntArray, radiusDp: Int, iconDp: Int): FrameLayout =
    FrameLayout(this).apply {
        background = gradientRect(colors, dpf(radiusDp))
        addView(iconView(res, Palette.WHITE), FrameLayout.LayoutParams(dp(iconDp), dp(iconDp), Gravity.CENTER))
    }

fun lin(
    width: Int,
    height: Int,
    weight: Float = 0f,
    top: Int = 0,
    bottom: Int = 0,
    start: Int = 0,
    end: Int = 0,
    gravity: Int = -1,
): LinearLayout.LayoutParams = LinearLayout.LayoutParams(width, height, weight).apply {
    topMargin = top
    bottomMargin = bottom
    marginStart = start
    marginEnd = end
    if (gravity != -1) this.gravity = gravity
}

/** Two or more options side by side; the selected one gets the violet gradient. */
fun Context.segmented(labels: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
    val box = LinearLayout(this).apply {
        background = roundRect(Palette.WHITE, dpf(18))
        elevation = dpf(2)
        setPadding(dp(6), dp(6), dp(6), dp(6))
    }
    val views = ArrayList<TextView>()
    fun paint(index: Int) {
        views.forEachIndexed { i, v ->
            v.isSelected = i == index
            if (i == index) {
                v.background = gradientRect(Palette.PURPLE, dpf(13))
                v.setTextColor(Palette.WHITE)
            } else {
                v.background = pressable(dpf(13))
                v.setTextColor(Palette.MUTED)
            }
        }
    }
    labels.forEachIndexed { i, text ->
        val v = label(text, 14f, Palette.MUTED, 700).apply {
            gravity = Gravity.CENTER
            setOnClickListener {
                paint(i)
                onSelect(i)
            }
        }
        views.add(v)
        box.addView(v, lin(0, dp(46), weight = 1f, start = if (i > 0) dp(6) else 0))
    }
    paint(selected)
    return box
}
