package com.privatelock.applock

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppEntry(val pkg: String, val label: String, val icon: Drawable)

sealed class Row {
    class Header(val title: String, val trailing: String?) : Row()
    class App(val entry: AppEntry, val locked: Boolean, val first: Boolean, val last: Boolean) : Row()
    class Hint(val text: String) : Row()
}

/** The list of apps on the home screen, grouped into "Locked apps" and "Other apps". */
class AppAdapter(
    private val context: Context,
    private val onToggle: (AppEntry, Boolean) -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var rows: List<Row> = emptyList()

    @SuppressLint("NotifyDataSetChanged")
    fun submit(newRows: List<Row>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = rows.size

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is Row.Header -> TYPE_HEADER
        is Row.App -> TYPE_APP
        is Row.Hint -> TYPE_HINT
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder = when (viewType) {
        TYPE_HEADER -> HeaderHolder(context)
        TYPE_APP -> AppHolder(context)
        else -> HintHolder(context)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is Row.Header -> (holder as HeaderHolder).bind(row)
            is Row.App -> (holder as AppHolder).bind(row, onToggle)
            is Row.Hint -> (holder as HintHolder).bind(row)
        }
    }

    private class HeaderHolder(ctx: Context) : RecyclerView.ViewHolder(LinearLayout(ctx)) {
        private val title = ctx.label("", 16f, Palette.INK, 800)
        private val trailing = ctx.label("", 13f, Palette.VIOLET, 700)

        init {
            val row = itemView as LinearLayout
            row.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(ctx.dp(2), ctx.dp(20), ctx.dp(2), ctx.dp(10))
            row.addView(title, lin(0, WRAP, weight = 1f))
            row.addView(trailing, lin(WRAP, WRAP))
        }

        fun bind(row: Row.Header) {
            title.text = row.title
            trailing.text = row.trailing ?: ""
            trailing.visibility = if (row.trailing == null) View.GONE else View.VISIBLE
        }
    }

    private class AppHolder(private val ctx: Context) : RecyclerView.ViewHolder(LinearLayout(ctx)) {
        private val icon = ImageView(ctx)
        private val name = ctx.label("", 15f, Palette.INK, 700).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        private val lockIcon = ctx.iconView(R.drawable.ic_lock, Palette.VIOLET)
        private val status = ctx.label("", 12f, Palette.MUTED, 700)
        private val toggle = PillSwitch(ctx)
        private val radius = ctx.dpf(22)

        init {
            val row = itemView as LinearLayout
            row.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
            row.gravity = Gravity.CENTER_VERTICAL
            row.minimumHeight = ctx.dp(62)
            row.setPadding(ctx.dp(14), ctx.dp(9), ctx.dp(14), ctx.dp(9))
            row.addView(icon, lin(ctx.dp(42), ctx.dp(42)))

            val texts = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(name, lin(MATCH, WRAP))
            val statusRow = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
            statusRow.addView(lockIcon, lin(ctx.dp(12), ctx.dp(12), end = ctx.dp(4)))
            statusRow.addView(status, lin(WRAP, WRAP))
            texts.addView(statusRow, lin(MATCH, WRAP, top = ctx.dp(3)))
            row.addView(texts, lin(0, WRAP, weight = 1f, start = ctx.dp(14), end = ctx.dp(10)))
            row.addView(toggle, lin(WRAP, WRAP))
            row.setOnClickListener { toggle.performClick() }
        }

        fun bind(row: Row.App, onToggle: (AppEntry, Boolean) -> Unit) {
            icon.setImageDrawable(row.entry.icon)
            name.text = row.entry.label
            showStatus(row.locked)
            toggle.isOn = row.locked
            toggle.contentDescription = ctx.getString(R.string.lock_app, row.entry.label)
            toggle.onChange = { on ->
                showStatus(on)
                onToggle(row.entry, on)
            }
            val top = if (row.first) radius else 0f
            val bottom = if (row.last) radius else 0f
            itemView.background = GradientDrawable().apply {
                setColor(Palette.WHITE)
                cornerRadii = floatArrayOf(top, top, top, top, bottom, bottom, bottom, bottom)
            }
        }

        private fun showStatus(locked: Boolean) {
            lockIcon.visibility = if (locked) View.VISIBLE else View.GONE
            status.text = ctx.getString(if (locked) R.string.locked else R.string.not_locked)
            status.setTextColor(if (locked) Palette.VIOLET else Palette.MUTED)
        }
    }

    private class HintHolder(ctx: Context) : RecyclerView.ViewHolder(TextView(ctx)) {
        init {
            val text = itemView as TextView
            text.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
            text.textSize = 14f
            text.setTextColor(Palette.MUTED)
            text.typeface = font(500)
            text.setPadding(ctx.dp(18), ctx.dp(18), ctx.dp(18), ctx.dp(18))
            text.background = roundRect(Palette.WHITE, ctx.dpf(22))
        }

        fun bind(row: Row.Hint) {
            (itemView as TextView).text = row.text
        }
    }

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_APP = 1
        private const val TYPE_HINT = 2
    }
}
