package com.privatelock.applock

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Switch

/** The rounded on/off switch from the mockup. [onHero] is the white version used on the purple card. */
class PillSwitch(context: Context, private val onHero: Boolean = false) : View(context) {

    var isOn = false
        set(value) {
            field = value
            invalidate()
        }

    var onChange: ((Boolean) -> Unit)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        isClickable = true
        isFocusable = true
        setOnClickListener {
            if (isEnabled) {
                isOn = !isOn
                onChange?.invoke(isOn)
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(context.dp(50), context.dp(30))
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        rect.set(0f, 0f, w, h)

        paint.shader = null
        paint.color = when {
            onHero && isOn -> Palette.WHITE
            onHero -> 0x4DFFFFFF
            isOn -> Palette.WHITE
            else -> Palette.OFF
        }
        if (!onHero && isOn) {
            paint.shader = LinearGradient(0f, 0f, w, h, Palette.VIOLET_LIGHT, Palette.VIOLET, Shader.TileMode.CLAMP)
        }
        canvas.drawRoundRect(rect, r, r, paint)

        val pad = context.dpf(4)
        val knob = r - pad
        val cx = if (isOn) w - pad - knob else pad + knob
        paint.shader = null
        paint.color = Palette.WHITE
        if (onHero && isOn) {
            paint.shader = LinearGradient(
                cx - knob, r - knob, cx + knob, r + knob,
                Palette.VIOLET_LIGHT, Palette.VIOLET, Shader.TileMode.CLAMP,
            )
        }
        canvas.drawCircle(cx, r, knob, paint)
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = if (enabled) 1f else 0.4f
    }

    override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(info)
        info.className = Switch::class.java.name
        info.isCheckable = true
        info.isChecked = isOn
    }
}
