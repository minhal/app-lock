package com.privatelock.applock

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Calendar
import java.util.concurrent.Executors

/**
 * App Lock's own screens: first-time setup, permissions, the app list and settings.
 * App Lock itself is protected by the same PIN or password.
 */
class MainActivity : AppCompatActivity() {

    private enum class Screen { HOME, SETTINGS, CHANGE }

    private class Hero(
        val pill: TextView,
        val title: TextView,
        val toggle: PillSwitch,
        val count: TextView,
        val delay: TextView,
    )

    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private var screen = Screen.HOME
    private var createPassword = false
    private var openingOtherApp = false
    private var apps: List<AppEntry>? = null
    private var loadingApps = false
    private var query = ""
    private var adapter: AppAdapter? = null
    private var hero: Hero? = null
    private val io = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        createPassword = prefs.isPassword
        if (savedInstanceState != null) {
            screen = Screen.valueOf(savedInstanceState.getString(KEY_SCREEN) ?: Screen.HOME.name)
            createPassword = savedInstanceState.getBoolean(KEY_CREATE_PASSWORD, createPassword)
        }

        root = FrameLayout(this)
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val inside = prefs.hasCredential && Session.selfUnlocked && Perms.all(this@MainActivity)
                if (inside && screen != Screen.HOME) {
                    screen = if (screen == Screen.CHANGE) Screen.SETTINGS else Screen.HOME
                    render()
                } else {
                    finish()
                }
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(KEY_SCREEN, screen.name)
        outState.putBoolean(KEY_CREATE_PASSWORD, createPassword)
    }

    override fun onResume() {
        super.onResume()
        openingOtherApp = false
        render()
        LockService.sync(this)
    }

    override fun onStop() {
        super.onStop()
        // App Lock locks itself whenever you leave it (but not while you grant a permission).
        if (!isChangingConfigurations && !openingOtherApp) Session.selfUnlocked = false
    }

    override fun onDestroy() {
        io.shutdown()
        super.onDestroy()
    }

    private fun render() {
        hero = null
        adapter = null
        root.removeAllViews()
        when {
            !prefs.hasCredential -> showCreate(setup = true)
            !Session.selfUnlocked -> showSelfLock()
            !Perms.all(this) -> showPermissions()
            screen == Screen.SETTINGS -> showSettings()
            screen == Screen.CHANGE -> showCreate(setup = false)
            else -> showHome()
        }
    }

    // ---------- Shared pieces ----------

    private fun lightScreen() {
        root.background = null
        root.setBackgroundColor(Palette.BG)
        systemBars(light = true)
    }

    private fun systemBars(light: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = light
        controller.isAppearanceLightNavigationBars = light
    }

    private fun page(): Pair<ScrollView, LinearLayout> {
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(24))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(column, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        return scroll to column
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = roundRect(Palette.WHITE, dpf(22))
        elevation = dpf(2)
    }

    private fun sectionTitle(res: Int): TextView = label(getString(res), 14f, Palette.MUTED, 800)

    private fun primaryButton(text: String, onClick: () -> Unit): TextView = label(text, 16f, Palette.WHITE, 800).apply {
        gravity = Gravity.CENTER
        background = ripple(gradientRect(Palette.PURPLE, dpf(18)), 0x40FFFFFF)
        elevation = dpf(6)
        if (Build.VERSION.SDK_INT >= 28) {
            outlineSpotShadowColor = Palette.VIOLET
            outlineAmbientShadowColor = Palette.VIOLET
        }
        setOnClickListener { onClick() }
    }

    private fun roundButton(icon: Int, description: Int, onClick: () -> Unit): FrameLayout = FrameLayout(this).apply {
        background = ripple(roundRect(Palette.WHITE, dpf(14)))
        elevation = dpf(3)
        contentDescription = getString(description)
        addView(iconView(icon, Palette.INK), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        setOnClickListener { onClick() }
    }

    private fun topBar(title: String, onBack: () -> Unit): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(roundButton(R.drawable.ic_back, R.string.back, onBack), lin(dp(44), dp(44)))
        addView(label(title, 22f, Palette.INK, 800), lin(WRAP, WRAP, start = dp(12)))
    }

    private fun progress(step: Int): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(View(context).apply { background = gradientRect(Palette.PURPLE, dpf(3)) }, lin(0, dp(6), weight = 1f))
        addView(View(context).apply {
            background = if (step >= 2) gradientRect(Palette.PURPLE, dpf(3)) else roundRect(Palette.OFF, dpf(3))
        }, lin(0, dp(6), weight = 1f, start = dp(10)))
        addView(label(getString(R.string.step, step), 13f, Palette.MUTED, 700), lin(WRAP, WRAP, start = dp(14)))
    }

    private fun illustration(): FrameLayout = FrameLayout(this).apply {
        addView(View(context).apply { background = oval(0x1F8C6BFF) }, FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER))
        addView(View(context).apply { background = oval(0x2E8C6BFF) }, FrameLayout.LayoutParams(dp(112), dp(112), Gravity.CENTER))
        addView(
            iconTile(R.drawable.ic_lock, intArrayOf(Palette.VIOLET_LIGHT, Palette.VIOLET, Palette.LOCK3), 24, 38).apply {
                elevation = dpf(10)
                if (Build.VERSION.SDK_INT >= 28) outlineSpotShadowColor = Palette.VIOLET
            },
            FrameLayout.LayoutParams(dp(78), dp(78), Gravity.CENTER),
        )
        addView(View(context).apply { background = oval(Palette.CORAL[0]) },
            FrameLayout.LayoutParams(dp(14), dp(14), Gravity.CENTER).apply {
                leftMargin = -dp(84)
                topMargin = -dp(52)
            })
        addView(View(context).apply { background = oval(Palette.BLUE[0]) },
            FrameLayout.LayoutParams(dp(10), dp(10), Gravity.CENTER).apply {
                leftMargin = dp(88)
                topMargin = dp(50)
            })
    }

    private fun hideKeyboard(view: View) {
        getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(view.windowToken, 0)
    }

    // ---------- Lock screen for App Lock itself ----------

    private fun showSelfLock() {
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Palette.LOCK1, Palette.LOCK2, Palette.LOCK3),
        )
        systemBars(light = false)
        val fingerprint = prefs.fingerprint && Bio.available(this)
        val icon = ContextCompat.getDrawable(this, R.mipmap.ic_launcher)!!
        val unlocked = {
            Session.selfUnlocked = true
            render()
        }
        val view = LockView(
            this, prefs, getString(R.string.app_name), icon, fingerprint,
            topInset = 0, bottomInset = 0,
            onUnlock = unlocked,
            onFingerprint = {
                Bio.prompt(this, getString(R.string.app_name), onSuccess = {
                    Session.registerSuccess()
                    unlocked()
                })
            },
            onBack = { finish() },
        )
        root.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ---------- Create or change the PIN / password ----------

    private fun showCreate(setup: Boolean) {
        lightScreen()
        val (_, column) = page()
        if (setup) {
            column.addView(progress(1), lin(MATCH, WRAP))
        } else {
            column.addView(topBar(getString(R.string.change_title)) {
                screen = Screen.SETTINGS
                render()
            }, lin(MATCH, WRAP))
        }
        column.addView(illustration(), lin(MATCH, dp(150), top = dp(12)))
        if (setup) {
            column.addView(label(getString(R.string.create_title), 26f, Palette.INK, 800).apply {
                gravity = Gravity.CENTER
            }, lin(MATCH, WRAP, top = dp(8)))
        }
        column.addView(label(getString(R.string.create_sub), 15f, Palette.MUTED, 500).apply {
            gravity = Gravity.CENTER
            setLineSpacing(0f, 1.3f)
        }, lin(MATCH, WRAP, top = dp(8)))

        column.addView(
            segmented(listOf(getString(R.string.pin), getString(R.string.password)), if (createPassword) 1 else 0) { i ->
                if ((i == 1) != createPassword) {
                    createPassword = i == 1
                    render()
                }
            },
            lin(MATCH, WRAP, top = dp(22)),
        )

        val first = secretField(getString(if (createPassword) R.string.new_password else R.string.new_pin))
        val second = secretField(getString(R.string.confirm))
        val error = label("", 14f, Palette.ERROR, 600).apply { visibility = View.GONE }
        val box = card().apply {
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(first, lin(MATCH, dp(54)))
            addView(second, lin(MATCH, dp(54), top = dp(12)))
            addView(error, lin(MATCH, WRAP, top = dp(12)))
        }
        column.addView(box, lin(MATCH, WRAP, top = dp(16)))
        column.addView(View(this), lin(MATCH, 0, weight = 1f))

        column.addView(primaryButton(getString(R.string.save)) {
            val a = first.text.toString()
            val b = second.text.toString()
            val problem = when {
                !createPassword && (a.length !in 4..8 || !a.all { it.isDigit() }) -> R.string.err_pin
                createPassword && a.length < 4 -> R.string.err_password
                a != b -> R.string.err_mismatch
                else -> 0
            }
            if (problem != 0) {
                error.text = getString(problem)
                error.visibility = View.VISIBLE
            } else {
                prefs.setCredential(createPassword, a)
                Session.selfUnlocked = true
                hideKeyboard(second)
                screen = if (setup) Screen.HOME else Screen.SETTINGS
                render()
            }
        }, lin(MATCH, dp(56), top = dp(20)))
    }

    private fun secretField(hint: String): EditText = EditText(this).apply {
        inputType = if (createPassword) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        if (!createPassword) filters = arrayOf<InputFilter>(InputFilter.LengthFilter(8))
        typeface = font(600)
        this.hint = hint
        textSize = 17f
        maxLines = 1
        setTextColor(Palette.INK)
        setHintTextColor(Palette.MUTED)
        background = roundRect(Palette.BG, dpf(14))
        setPadding(dp(16), 0, dp(16), 0)
    }

    // ---------- Permissions ----------

    private fun showPermissions() {
        lightScreen()
        val (_, column) = page()
        column.addView(progress(2), lin(MATCH, WRAP))
        column.addView(illustration(), lin(MATCH, dp(150), top = dp(12)))
        column.addView(label(getString(R.string.almost_ready), 26f, Palette.INK, 800).apply {
            gravity = Gravity.CENTER
        }, lin(MATCH, WRAP, top = dp(8)))
        column.addView(label(getString(R.string.perms_sub), 15f, Palette.MUTED, 500).apply {
            gravity = Gravity.CENTER
            setLineSpacing(0f, 1.3f)
        }, lin(MATCH, WRAP, top = dp(8)))

        val usageOk = Perms.usage(this)
        val overlayOk = Perms.overlay(this)
        column.addView(permissionCard(R.drawable.ic_usage, Palette.BLUE, R.string.usage_title, R.string.usage_sub, usageOk) {
            openSettings(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }, lin(MATCH, WRAP, top = dp(22)))
        column.addView(permissionCard(R.drawable.ic_layers, Palette.CORAL, R.string.overlay_title, R.string.overlay_sub, overlayOk) {
            openSettings(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, lin(MATCH, WRAP, top = dp(12)))

        val note = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = roundRect(Palette.LAVENDER, dpf(16))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addView(iconView(R.drawable.ic_shield, Palette.VIOLET), lin(dp(18), dp(18)))
            addView(label(getString(R.string.privacy_note), 13f, Palette.LAVENDER_INK, 600), lin(0, WRAP, weight = 1f, start = dp(12)))
        }
        column.addView(note, lin(MATCH, WRAP, top = dp(16)))
        column.addView(View(this), lin(MATCH, 0, weight = 1f))
        column.addView(primaryButton(getString(R.string.continue_label)) {
            when {
                !Perms.usage(this) -> openSettings(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                !Perms.overlay(this) -> openSettings(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                else -> render()
            }
        }, lin(MATCH, dp(56), top = dp(20)))
    }

    private fun permissionCard(icon: Int, colors: IntArray, title: Int, subtitle: Int, granted: Boolean, onAllow: () -> Unit): View {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = roundRect(Palette.WHITE, dpf(22))
            elevation = dpf(2)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        row.addView(iconTile(icon, colors, 14, 20), lin(dp(44), dp(44)))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(getString(title), 15f, Palette.INK, 700), lin(MATCH, WRAP))
        texts.addView(label(getString(subtitle), 13f, Palette.MUTED, 500), lin(MATCH, WRAP, top = dp(2)))
        row.addView(texts, lin(0, WRAP, weight = 1f, start = dp(14), end = dp(10)))
        if (granted) {
            row.addView(FrameLayout(this).apply {
                background = gradientRect(Palette.PURPLE, dpf(15))
                contentDescription = getString(R.string.granted)
                addView(iconView(R.drawable.ic_check, Palette.WHITE), FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
            }, lin(dp(30), dp(30)))
        } else {
            row.addView(label(getString(R.string.allow), 14f, Palette.VIOLET, 800).apply {
                gravity = Gravity.CENTER
                background = ripple(roundRect(Palette.LAVENDER, dpf(19)))
                setPadding(dp(16), 0, dp(16), 0)
                setOnClickListener { onAllow() }
            }, lin(WRAP, dp(38)))
        }
        return row
    }

    private fun openSettings(intent: Intent) {
        openingOtherApp = true
        // Don't block the user with our own lock while they grant a permission.
        Session.unlock(Prefs.SETTINGS_PACKAGE)
        try {
            startActivity(intent)
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (_: Exception) {
                openingOtherApp = false
            }
        }
    }

    // ---------- Home: the list of apps ----------

    private fun showHome() {
        lightScreen()
        askNotificationsOnce()
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        column.addView(homeHeader(), lin(MATCH, WRAP))
        column.addView(heroCard(), lin(MATCH, WRAP, top = dp(18)))
        column.addView(searchBox(), lin(MATCH, dp(48), top = dp(16)))

        val list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(context)
            clipToPadding = false
            setPadding(0, dp(4), 0, dp(24))
            itemAnimator = null
        }
        val newAdapter = AppAdapter(this) { entry, locked ->
            prefs.setLocked(entry.pkg, locked)
            LockService.sync(this)
            updateHero()
            root.postDelayed({ refreshRows() }, 250)
        }
        list.adapter = newAdapter
        adapter = newAdapter
        column.addView(list, lin(MATCH, 0, weight = 1f, top = dp(4)))
        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        refreshRows()
        loadApps()
    }

    private fun homeHeader(): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(iconTile(R.drawable.ic_shield, Palette.PURPLE, 13, 22).apply {
            elevation = dpf(6)
            if (Build.VERSION.SDK_INT >= 28) outlineSpotShadowColor = Palette.VIOLET
        }, lin(dp(42), dp(42)))
        val texts = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(getString(greeting()), 13f, Palette.MUTED, 600), lin(WRAP, WRAP))
        texts.addView(label(getString(R.string.app_name), 22f, Palette.INK, 800), lin(WRAP, WRAP))
        addView(texts, lin(0, WRAP, weight = 1f, start = dp(12)))
        addView(roundButton(R.drawable.ic_tune, R.string.settings) {
            screen = Screen.SETTINGS
            render()
        }, lin(dp(44), dp(44)))
    }

    private fun greeting(): Int {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hour < 12 -> R.string.good_morning
            hour < 17 -> R.string.good_afternoon
            else -> R.string.good_evening
        }
    }

    private fun heroCard(): View {
        val card = FrameLayout(this).apply {
            background = gradientRect(intArrayOf(Palette.VIOLET_LIGHT, Palette.VIOLET, Palette.VIOLET_DARK), dpf(26))
            clipToOutline = true
            elevation = dpf(10)
            if (Build.VERSION.SDK_INT >= 28) {
                outlineSpotShadowColor = Palette.VIOLET
                outlineAmbientShadowColor = Palette.VIOLET
            }
        }
        card.addView(View(this).apply { background = oval(0x1AFFFFFF) },
            FrameLayout.LayoutParams(dp(180), dp(180), Gravity.TOP or Gravity.END).apply {
                topMargin = -dp(50)
                rightMargin = -dp(40)
            })
        card.addView(View(this).apply { background = oval(0x47FF7A59) },
            FrameLayout.LayoutParams(dp(140), dp(140), Gravity.BOTTOM or Gravity.END).apply {
                bottomMargin = -dp(70)
                rightMargin = dp(30)
            })

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pill = label("", 12f, Palette.WHITE, 700).apply {
            background = roundRect(0x2EFFFFFF, dpf(20))
            setPadding(dp(10), dp(5), dp(10), dp(5))
            letterSpacing = 0.05f
        }
        texts.addView(pill, lin(WRAP, WRAP))
        val title = label("", 22f, Palette.WHITE, 800)
        texts.addView(title, lin(WRAP, WRAP, top = dp(8)))
        top.addView(texts, lin(0, WRAP, weight = 1f))
        val toggle = PillSwitch(this, onHero = true).apply { contentDescription = getString(R.string.protection) }
        top.addView(toggle, lin(WRAP, WRAP))
        column.addView(top, lin(MATCH, WRAP))

        val stats = LinearLayout(this)
        val (countBox, count) = statBox(getString(R.string.apps_locked))
        val (delayBox, delay) = statBox(getString(R.string.relock_delay))
        stats.addView(countBox, lin(0, WRAP, weight = 1f))
        stats.addView(delayBox, lin(0, WRAP, weight = 1f, start = dp(10)))
        column.addView(stats, lin(MATCH, WRAP, top = dp(18)))
        card.addView(column, FrameLayout.LayoutParams(MATCH, WRAP))

        hero = Hero(pill, title, toggle, count, delay)
        toggle.onChange = { on ->
            prefs.protectionOn = on
            LockService.sync(this)
            updateHero()
        }
        updateHero()
        return card
    }

    private fun statBox(caption: String): Pair<View, TextView> {
        val value = label("", 24f, Palette.WHITE, 800)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(0x29FFFFFF, dpf(16))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addView(value, lin(WRAP, WRAP))
            addView(label(caption, 13f, Palette.WHITE, 600), lin(WRAP, WRAP, top = dp(2)))
        }
        return box to value
    }

    private fun updateHero() {
        val h = hero ?: return
        val on = prefs.protectionOn
        h.toggle.isOn = on
        h.pill.text = getString(if (on) R.string.active else R.string.paused)
        h.title.text = getString(if (on) R.string.protection_on else R.string.protection_off)
        val locked = prefs.lockedApps()
        h.count.text = (apps?.count { it.pkg in locked } ?: locked.size).toString()
        h.delay.text = when (val s = prefs.relockSeconds) {
            0 -> getString(R.string.now)
            in 1..59 -> "${s}s"
            else -> "${s / 60}m"
        }
    }

    private fun searchBox(): View {
        val box = FrameLayout(this).apply {
            background = roundRect(Palette.WHITE, dpf(16))
            elevation = dpf(2)
        }
        box.addView(iconView(R.drawable.ic_search, Palette.MUTED),
            FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER_VERTICAL or Gravity.START).apply {
                marginStart = dp(16)
            })
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            typeface = font(500)
            background = null
            hint = getString(R.string.search_apps)
            setHintTextColor(Palette.MUTED)
            setTextColor(Palette.INK)
            textSize = 15f
            maxLines = 1
            setPadding(dp(44), 0, dp(16), 0)
            setText(query)
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                refreshRows()
            }
        })
        box.addView(input, FrameLayout.LayoutParams(MATCH, MATCH))
        return box
    }

    private fun loadApps() {
        if (loadingApps) return
        loadingApps = true
        io.execute {
            val pm = packageManager
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val packages = pm.queryIntentActivities(launcher, 0)
                .map { it.activityInfo.packageName }
                .distinct()
                .filter { it != packageName }
            val list = packages.mapNotNull { pkg ->
                try {
                    val info = pm.getApplicationInfo(pkg, 0)
                    AppEntry(pkg, pm.getApplicationLabel(info).toString(), pm.getApplicationIcon(info))
                } catch (_: Exception) {
                    null
                }
            }.sortedBy { it.label.lowercase() }
            runOnUiThread {
                loadingApps = false
                apps = list
                if (!isDestroyed) refreshRows()
            }
        }
    }

    private fun refreshRows() {
        val a = adapter ?: return
        val all = apps
        if (all == null) {
            a.submit(listOf(Row.Hint(getString(R.string.loading))))
            updateHero()
            return
        }
        val locked = prefs.lockedApps()
        val q = query.trim().lowercase()
        val shown = if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) }
        val lockedShown = shown.filter { it.pkg in locked }
        val otherShown = shown.filter { it.pkg !in locked }

        val rows = ArrayList<Row>()
        rows.add(Row.Header(getString(R.string.locked_apps), getString(R.string.count_of, all.count { it.pkg in locked }, all.size)))
        if (lockedShown.isEmpty()) {
            rows.add(Row.Hint(getString(if (q.isEmpty()) R.string.empty_locked else R.string.no_match)))
        } else {
            lockedShown.forEachIndexed { i, e -> rows.add(Row.App(e, true, i == 0, i == lockedShown.lastIndex)) }
        }
        rows.add(Row.Header(getString(R.string.other_apps), null))
        if (otherShown.isEmpty()) {
            rows.add(Row.Hint(getString(if (q.isEmpty()) R.string.all_locked else R.string.no_match)))
        } else {
            otherShown.forEachIndexed { i, e -> rows.add(Row.App(e, false, i == 0, i == otherShown.lastIndex)) }
        }
        a.submit(rows)
        updateHero()
    }

    private fun askNotificationsOnce() {
        if (Build.VERSION.SDK_INT < 33 || prefs.askedNotifications) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        prefs.askedNotifications = true
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
    }

    // ---------- Settings ----------

    private fun showSettings() {
        lightScreen()
        val (_, column) = page()
        column.addView(topBar(getString(R.string.settings)) {
            screen = Screen.HOME
            render()
        }, lin(MATCH, WRAP))

        column.addView(sectionTitle(R.string.unlock_with), lin(MATCH, WRAP, top = dp(22)))
        column.addView(
            segmented(listOf(getString(R.string.pin), getString(R.string.password)), if (prefs.isPassword) 1 else 0) { i ->
                val wantPassword = i == 1
                if (wantPassword != prefs.isPassword) {
                    createPassword = wantPassword
                    screen = Screen.CHANGE
                    render()
                }
            },
            lin(MATCH, WRAP, top = dp(10)),
        )

        column.addView(sectionTitle(R.string.security), lin(MATCH, WRAP, top = dp(22)))
        val security = card().apply { setPadding(dp(14), dp(4), dp(14), dp(4)) }
        security.addView(settingsRow(
            R.drawable.ic_key, Palette.PURPLE,
            getString(if (prefs.isPassword) R.string.change_password else R.string.change_pin), null,
            iconView(R.drawable.ic_chevron, Palette.CHEVRON),
        ) {
            createPassword = prefs.isPassword
            screen = Screen.CHANGE
            render()
        })
        security.addView(divider())
        val bioOk = Bio.available(this)
        val fingerprintSwitch = PillSwitch(this).apply {
            isOn = prefs.fingerprint && bioOk
            isEnabled = bioOk
            contentDescription = getString(R.string.fingerprint_unlock)
            onChange = { prefs.fingerprint = it }
        }
        security.addView(settingsRow(
            R.drawable.ic_fingerprint, Palette.PINK, getString(R.string.fingerprint_unlock),
            if (bioOk) null else getString(R.string.fingerprint_unavailable), fingerprintSwitch,
        ))
        column.addView(security, lin(MATCH, WRAP, top = dp(10)))

        column.addView(sectionTitle(R.string.lock_again_after), lin(MATCH, WRAP, top = dp(22)))
        val choices = Prefs.RELOCK_CHOICES
        val current = choices.indexOf(prefs.relockSeconds).let { if (it < 0) 1 else it }
        column.addView(
            segmented(
                listOf(getString(R.string.now), getString(R.string.sec_30), getString(R.string.min_1), getString(R.string.min_5)),
                current,
            ) { i -> prefs.relockSeconds = choices[i] },
            lin(MATCH, WRAP, top = dp(10)),
        )

        column.addView(sectionTitle(R.string.protection), lin(MATCH, WRAP, top = dp(22)))
        val protection = card().apply { setPadding(dp(14), dp(4), dp(14), dp(4)) }
        val uninstallSwitch = PillSwitch(this).apply {
            isOn = prefs.preventUninstall
            contentDescription = getString(R.string.prevent_uninstall)
            onChange = { prefs.preventUninstall = it }
        }
        protection.addView(settingsRow(
            R.drawable.ic_trash, Palette.CORAL, getString(R.string.prevent_uninstall),
            getString(R.string.prevent_uninstall_sub), uninstallSwitch,
        ))
        protection.addView(divider())
        val newAppsSwitch = PillSwitch(this).apply {
            isOn = prefs.autoLockNew
            contentDescription = getString(R.string.lock_new_apps)
            onChange = { prefs.autoLockNew = it }
        }
        protection.addView(settingsRow(
            R.drawable.ic_plus, Palette.AMBER, getString(R.string.lock_new_apps),
            getString(R.string.lock_new_apps_sub), newAppsSwitch,
        ))
        column.addView(protection, lin(MATCH, WRAP, top = dp(10)))

        column.addView(View(this), lin(MATCH, 0, weight = 1f, top = dp(24)))
        column.addView(label(getString(R.string.footer_privacy), 13f, Palette.VIOLET, 800).apply {
            gravity = Gravity.CENTER
        }, lin(MATCH, WRAP))
        column.addView(label(getString(R.string.version, BuildConfig.VERSION_NAME), 12f, Palette.MUTED, 500).apply {
            gravity = Gravity.CENTER
        }, lin(MATCH, WRAP, top = dp(4)))
    }

    private fun settingsRow(
        icon: Int,
        colors: IntArray,
        title: String,
        subtitle: String?,
        trailing: View,
        onClick: (() -> Unit)? = null,
    ): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        minimumHeight = dp(60)
        setPadding(0, dp(10), 0, dp(10))
        addView(iconTile(icon, colors, 11, 17), lin(dp(34), dp(34)))
        val texts = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title, 15f, Palette.INK, 700), lin(MATCH, WRAP))
        if (subtitle != null) texts.addView(label(subtitle, 12f, Palette.MUTED, 500), lin(MATCH, WRAP, top = dp(2)))
        addView(texts, lin(0, WRAP, weight = 1f, start = dp(12), end = dp(10)))
        addView(trailing, lin(WRAP, WRAP))
        background = pressable(dpf(12))
        setOnClickListener {
            if (onClick != null) onClick()
            else if (trailing.isEnabled) trailing.performClick()
        }
    }

    private fun divider(): View = View(this).apply {
        setBackgroundColor(Palette.DIVIDER)
        layoutParams = lin(MATCH, 1, start = dp(46))
    }

    companion object {
        private const val KEY_SCREEN = "screen"
        private const val KEY_CREATE_PASSWORD = "create_password"
    }
}
